// Please run your solution from this file

console.log("Hello from %csrc/index.js", "font-weight:bold");
