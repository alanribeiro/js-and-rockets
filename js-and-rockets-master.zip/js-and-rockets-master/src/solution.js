// Please implement your solution in this file

const noop = () => {};

module.exports = {
  prepareData: noop,
  renderData: noop
};
